# CB4
2016 FRC Stronghold robot code. 

Please fork this code to make changes.

***

##TODO:
- ~~Make / find eclipse compatible .gitignore, which is needed so that code can be shared without breaking.~~
- ~~Everyone needs to get a test commit merged.~~
- ~~Make awesome code and keep our robot "happy".~~
- ~~Explain what Saros is and why it's such a great developing tool.
(Seriously, look at it. http://www.saros-project.org/)~~
